import {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  MessageFlags,
} from 'discord.js';

import { createEmbed, successEmbed } from '../utils/embeds.js';
import {
  createTicket,
  closeTicket,
  claimTicket,
  updateTicketPriority,
} from '../services/ticket.js';
import { getGuildConfig } from '../services/config/guildConfig.js';
import { logTicketEvent } from '../utils/ticket/ticketLogging.js';
import { logger } from '../utils/logger.js';
import { InteractionHelper } from '../utils/interactionHelper.js';
import { checkRateLimit } from '../utils/rateLimiter.js';
import {
  replyUserError,
  ErrorTypes,
  handleInteractionError,
  createError,
} from '../utils/errorHandler.js';
import { getTicketPermissionContext } from '../utils/ticket/ticketPermissions.js';

async function ensureGuildContext(interaction) {
  if (interaction.inGuild()) {
    return true;
  }

  if (!interaction.replied && !interaction.deferred) {
    await replyUserError(interaction, {
      type: ErrorTypes.UNKNOWN,
      message: 'This action can only be used in a server.',
    });
  }

  return false;
}

async function assertTicketPermission(
  interaction,
  client,
  actionLabel,
  options = {},
  timeoutMs = 2500
) {
  const { allowTicketCreator = false } = options;

  let context;

  try {
    const contextPromise = getTicketPermissionContext({
      client,
      interaction,
    });

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(
        () => reject(new Error('Timeout')),
        timeoutMs
      )
    );

    context = await Promise.race([
      contextPromise,
      timeoutPromise,
    ]);
  } catch (error) {
    if (error.message === 'Timeout') {
      throw createError(
        'Ticket permission timeout',
        ErrorTypes.RATE_LIMIT,
        'The permission check took too long. Please try again.'
      );
    }

    throw createError(
      'Ticket permission check failed',
      ErrorTypes.UNKNOWN,
      `Failed to check permissions: ${error.message}`
    );
  }

  if (!context.ticketData) {
    throw createError(
      'Not a ticket channel',
      ErrorTypes.VALIDATION,
      'This action can only be used in a valid ticket channel.'
    );
  }

  const allowed = allowTicketCreator
    ? context.canCloseTicket
    : context.canManageTicket;

  if (!allowed) {
    const permissionMessage = allowTicketCreator
      ? 'You must have **Manage Channels**, the configured **Ticket Staff Role**, or be the **ticket creator**.'
      : 'You must have **Manage Channels** or the configured **Ticket Staff Role**.';

    throw createError(
      'Ticket permission denied',
      ErrorTypes.PERMISSION,
      `${permissionMessage}\n\nYou cannot ${actionLabel}.`
    );
  }

  return context;
}

/**
 * Creates a ticket directly.
 *
 * There is intentionally NO modal here anymore.
 * Clicking "Solicitate" immediately creates the ticket
 * without asking for a reason.
 */
const createTicketHandler = {
  name: 'create_ticket',

  async execute(interaction, client) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      const rateLimitKey =
        `${interaction.user.id}:create_ticket`;

      const allowed = await checkRateLimit(
        rateLimitKey,
        3,
        60000
      );

      if (!allowed) {
        await replyUserError(interaction, {
          type: ErrorTypes.RATE_LIMIT,
          message:
            'You are creating tickets too quickly. Please wait a minute and try again.',
        });

        return;
      }

      const config = await getGuildConfig(
        client,
        interaction.guildId
      );

      const maxTicketsPerUser =
        config.maxTicketsPerUser || 3;

      const {
        getUserTicketCount,
      } = await import('../services/ticket.js');

      const currentTicketCount =
        await getUserTicketCount(
          interaction.guildId,
          interaction.user.id
        );

      if (
        currentTicketCount >=
        maxTicketsPerUser
      ) {
        await replyUserError(interaction, {
          type: ErrorTypes.UNKNOWN,
          message:
            `You have reached the maximum number of open tickets (${maxTicketsPerUser}).\n\n` +
            'Please close your existing tickets before creating a new one.\n\n' +
            `**Current Tickets:** ${currentTicketCount}/${maxTicketsPerUser}`,
        });

        return;
      }

      /*
       * No reason is requested anymore.
       * The ticket service will receive this default value.
       */
      const categoryId =
        config.ticketCategoryId || null;

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const { channel } =
        await createTicket(
          interaction.guild,
          interaction.member,
          categoryId,
          'No reason provided'
        );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Created',
            `Your ticket has been created in ${channel}!`
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error creating ticket:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

/**
 * Kept for compatibility with the existing loader.
 *
 * Since ticket creation no longer uses a modal,
 * this handler should never normally be called.
 */
const createTicketModalHandler = {
  name: 'create_ticket_modal',

  async execute(interaction, client) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const config =
        await getGuildConfig(
          client,
          interaction.guildId
        );

      const categoryId =
        config.ticketCategoryId || null;

      const { channel } =
        await createTicket(
          interaction.guild,
          interaction.member,
          categoryId,
          'No reason provided'
        );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Created',
            `Your ticket has been created in ${channel}!`
          ),
        ],
      });
    } catch (error) {
      await handleInteractionError(
        interaction,
        error,
        {
          type: 'modal',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const closeTicketHandler = {
  name: 'ticket_close',

  async execute(interaction, client) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'close this ticket',
        {
          allowTicketCreator: true,
        },
        2000
      );

      const modal =
        new ModalBuilder()
          .setCustomId(
            'ticket_close_modal'
          )
          .setTitle(
            'Close Ticket'
          );

      const reasonInput =
        new TextInputBuilder()
          .setCustomId('reason')
          .setLabel(
            'Reason for closing (optional)'
          )
          .setStyle(
            TextInputStyle.Paragraph
          )
          .setPlaceholder(
            'Add an optional reason for closing this ticket...'
          )
          .setRequired(false)
          .setMaxLength(1000);

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          reasonInput
        )
      );

      await interaction.showModal(
        modal
      );
    } catch (error) {
      logger.error(
        'Error closing ticket:',
        error
      );

      if (
        !interaction.replied &&
        !interaction.deferred
      ) {
        await replyUserError(
          interaction,
          {
            type: ErrorTypes.UNKNOWN,
            message:
              'Could not open ticket close form.',
          }
        );
      }
    }
  },
};

const closeTicketModalHandler = {
  name: 'ticket_close_modal',

  async execute(interaction, client) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'close this ticket',
        {
          allowTicketCreator: true,
        },
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const providedReason =
        interaction.fields
          .getTextInputValue(
            'reason'
          )
          ?.trim();

      const reason =
        providedReason ||
        'Closed via ticket button without a specific reason.';

      await closeTicket(
        interaction.channel,
        interaction.user,
        reason
      );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Closed',
            'This ticket has been closed.'
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error submitting close ticket modal:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'modal',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const claimTicketHandler = {
  name: 'ticket_claim',

  async execute(interaction, client) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'claim tickets',
        {},
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      await claimTicket(
        interaction.channel,
        interaction.user
      );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Claimed',
            'You have claimed this ticket.'
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error claiming ticket:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const priorityTicketHandler = {
  name: 'ticket_priority',

  async execute(
    interaction,
    client,
    args
  ) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'change ticket priority',
        {},
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const priority =
        args?.[0];

      if (!priority) {
        await replyUserError(
          interaction,
          {
            type:
              ErrorTypes.VALIDATION,
            message:
              'A priority value is required.',
          }
        );

        return;
      }

      await updateTicketPriority(
        interaction.channel,
        priority,
        interaction.user
      );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Priority Updated',
            `Ticket priority set to **${priority.toUpperCase()}**.`
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error updating ticket priority:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const pinTicketHandler = {
  name: 'ticket_pin',

  async execute(interaction, client) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'pin tickets',
        {},
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const channel =
        interaction.channel;

      const category =
        channel.parent;

      if (!category) {
        await replyUserError(
          interaction,
          {
            type:
              ErrorTypes.UNKNOWN,
            message:
              'This ticket is not in a category.',
          }
        );

        return;
      }

      const hasPinEmoji =
        channel.name.startsWith('📌');

      if (hasPinEmoji) {
        const newName =
          channel.name.replace(
            /^📌\s*/,
            ''
          );

        await channel.edit({
          name: newName,
          position: 999,
        });

        await interaction.editReply({
          embeds: [
            createEmbed({
              title:
                '📌 Ticket Unpinned',
              description:
                'This ticket has been unpinned and moved back to normal position.',
              color: 0x95A5A6,
            }),
          ],
        });

        logger.info(
          'Ticket unpinned',
          {
            guildId:
              interaction.guildId,
            channelId:
              channel.id,
            channelName:
              newName,
            userId:
              interaction.user.id,
          }
        );
      } else {
        const pinnedName =
          `📌 ${channel.name}`;

        await channel.edit({
          name: pinnedName,
          position: 0,
        });

        await interaction.editReply({
          embeds: [
            createEmbed({
              title:
                '📌 Ticket Pinned',
              description:
                'This ticket has been pinned to the top of the category.',
              color: 0x3498db,
            }),
          ],
        });

        logger.info(
          'Ticket pinned',
          {
            guildId:
              interaction.guildId,
            channelId:
              channel.id,
            channelName:
              pinnedName,
            userId:
              interaction.user.id,
          }
        );
      }

      await logTicketEvent({
        client:
          interaction.client,
        guildId:
          interaction.guildId,
        event: {
          type:
            hasPinEmoji
              ? 'unpin'
              : 'pin',

          ticketId:
            channel.id,

          ticketNumber:
            channel.name.replace(
              /[^0-9]/g,
              ''
            ),

          userId:
            interaction.user.id,

          executorId:
            interaction.user.id,

          metadata: {
            isPinned:
              !hasPinEmoji,

            newChannelName:
              hasPinEmoji
                ? channel.name.replace(
                    /^📌\s*/,
                    ''
                  )
                : `📌 ${channel.name}`,
          },
        },
      });
    } catch (error) {
      logger.error(
        'Error pinning/unpinning ticket:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const unclaimTicketHandler = {
  name: 'ticket_unclaim',

  async execute(
    interaction,
    client
  ) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'unclaim tickets',
        {},
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags: MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const {
        unclaimTicket,
      } = await import(
        '../services/ticket.js'
      );

      await unclaimTicket(
        interaction.channel,
        interaction.member
      );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Unclaimed',
            'This ticket has been unclaimed.'
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error unclaiming ticket:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const reopenTicketHandler = {
  name: 'ticket_reopen',

  async execute(
    interaction,
    client
  ) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'reopen tickets',
        {},
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags:
              MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const {
        reopenTicket,
      } = await import(
        '../services/ticket.js'
      );

      const {
        movedToOpenCategory,
        openCategoryMoveFailed,
      } = await reopenTicket(
        interaction.channel,
        interaction.member
      );

      let reopenMessage =
        'This ticket has been reopened.';

      if (openCategoryMoveFailed) {
        reopenMessage +=
          ' Note: Could not move the channel back to the open tickets category.';
      }

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Reopened',
            reopenMessage
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error reopening ticket:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

const deleteTicketHandler = {
  name: 'ticket_delete',

  async execute(
    interaction,
    client
  ) {
    try {
      if (!(await ensureGuildContext(interaction))) {
        return;
      }

      await assertTicketPermission(
        interaction,
        client,
        'delete tickets',
        {},
        2000
      );

      const deferSuccess =
        await InteractionHelper.safeDefer(
          interaction,
          {
            flags:
              MessageFlags.Ephemeral,
          }
        );

      if (!deferSuccess) {
        return;
      }

      const {
        deleteTicket,
      } = await import(
        '../services/ticket.js'
      );

      await deleteTicket(
        interaction.channel,
        interaction.member
      );

      await interaction.editReply({
        embeds: [
          successEmbed(
            'Ticket Deleted',
            'This ticket will be deleted shortly.'
          ),
        ],
      });
    } catch (error) {
      logger.error(
        'Error deleting ticket:',
        error
      );

      await handleInteractionError(
        interaction,
        error,
        {
          type: 'button',
          handler: 'ticket',
          customId:
            interaction.customId,
        }
      );
    }
  },
};

export default createTicketHandler;

export {
  createTicketModalHandler,
  closeTicketModalHandler,
  closeTicketHandler,
  claimTicketHandler,
  priorityTicketHandler,
  pinTicketHandler,
  unclaimTicketHandler,
  reopenTicketHandler,
  deleteTicketHandler,
};
